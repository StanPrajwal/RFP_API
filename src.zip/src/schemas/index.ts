const MONGO_MODEL_NAMES = {
  RFP: 'RFP',
  VENDOR: 'Vendor',
  PROPOSAL: 'Proposal',
  EmailOutbound: 'EmailOutbound',
  EmailInbound: 'EmailInbound',
};

export { MONGO_MODEL_NAMES };
